# Assignment 3: Python - Function (User-Defined, Recursive, Lambda, Map, Filter)

## Overview

This folder contains seven Jupyter Notebooks with practical exercises covering Function (User-Defined, Recursive, Lambda, Map, Filter).

## Project Structure

The notebooks are named using the format `task<task-no>.ipynb`, where `<task-no>` is the task number.

For example:
- `task1.ipynb`
- `task2.ipynb`
- `task3.ipynb`
- `task4.ipynb`
- `task5.ipynb`
- `task6.ipynb`
- `task7.ipynb`

## Requirements

- Python 3

## Setup and Execution

### 1. Extract the ZIP file

Extract the ZIP file to a folder on your computer.

### 2. Open a terminal in the extracted folder

Navigate into the extracted project folder:

```bash
cd path/to/GenAI-Task9-SwapnilTaparia
```

### 3. (Recommended) Create and activate a virtual environment

**macOS / Linux**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

**Windows**

```powershell
python -m venv .venv
.venv\\Scripts\\activate
```

### 4. Start Jupyter Notebook

```bash
python -m notebook
```

Jupyter Notebook will open in your web browser. If it does not open automatically, copy the local URL shown in the terminal into your browser.

### 5. Run a notebook

1. Open the notebook you want to run (for example, `task1.ipynb`).
2. Run a cell using **Shift + Enter**, or use **Run → Run All** to execute all cells.
3. Repeat for the other task notebooks as needed.

## Notes

- Install the required packages before running the notebooks.
- Run cells in order, from top to bottom.
- The `.venv` folder is created locally during setup and does not need to be included in the ZIP.
- No Git installation or repository cloning is required.

## Deactivating the Virtual Environment

When you have finished, run:

```bash
deactivate
```
